%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Matlab Source Code for
%%% Strength Pareto particle swarm optimization and hybrid EA-PSO for multi-objective optimization
%%% https://doi.org/10.1162/evco.2010.18.1.18105  

%%%%%%%%%%%  Programmed By: Yousef Abdi
%%%%%%%%%%%  E-mail: yousef.abdi@gmail.com, y.abdi@tabrizu.ac.ir
%%%%%%%%%%%  November 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;
close all;
for Problem=[1 2 3 4 6]
    
    %% Problem Definition
    prob=num2str(Problem);
    CostFunction=str2func(['@(x)  ZDT' prob '(x)']);  %Cost Function
    load(['Problem_PFs\ZDT' prob ]);
    problemName=['ZDT' prob];
    
    switch Problem
        case num2cell([1 2 3])
            nVar=30;
            VarMin(1:nVar,1)=0;
            VarMax(1:nVar,1)=+1;
        case 4
            nVar=10;
            VarMin(1,1)=0;
            VarMax(1,1)=1;
            VarMin(2:nVar,1)=-5;
            VarMax(2:nVar,1)=5;
        case 6
            nVar=10;
            VarMin(1:nVar,1)=0;
            VarMax(1:nVar,1)=1;
    end
    
    VarSize=[nVar 1];
    TotalRun=30;
    %% SPEA2 Settings

    MaxIt=100;        % Maximum Number of Iterations

    nPop=100;            % Population Size

    nArchive=100;        % Archive Size

    K=round(sqrt(nPop+nArchive));  % KNN Parameter

    pCrossover=0.95;
    nCrossover=round(pCrossover*nPop/2)*2;

    pMutation=1-pCrossover;
    nMutation=nPop-nCrossover;

    crossover_params.gamma=0.1;
    crossover_params.VarMin=VarMin;
    crossover_params.VarMax=VarMax;

    mutation_params.h=0.2;
    mutation_params.VarMin=VarMin;
    mutation_params.VarMax=VarMax;
    
    %% Initialization

    empty_individual.Position=[];
    empty_individual.Velocity=[];
    empty_individual.PBest=[];
    empty_individual.Cost=[];
    empty_individual.PCost=[];
    empty_individual.S=[];
    empty_individual.R=[];
    empty_individual.sigma=[];
    empty_individual.sigmaK=[];
    empty_individual.D=[];
    empty_individual.F=[];
    
    IGDs=zeros(MaxIt, TotalRun);
    HVs=zeros(MaxIt, TotalRun);    
    
    for run=1:TotalRun
        pop=repmat(empty_individual,nPop,1);
        for i=1:nPop
            pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
            pop(i).Velocity=zeros(VarSize);
            pop(i).PBest=pop(i).Position;
            pop(i).Cost=CostFunction((pop(i).Position)');
            pop(i).PCost=pop(i).Cost;
        end

        archive=[];

        %% Main Loop
        for it=1:MaxIt

            Q=[pop
               archive];

            nQ=numel(Q);

            dom=false(nQ,nQ);

            for i=1:nQ
                Q(i).S=0;
            end

            for i=1:nQ
                for j=i+1:nQ

                    if Dominates(Q(i),Q(j))
                        Q(i).S=Q(i).S+1;
                        dom(i,j)=true;

                    elseif Dominates(Q(j),Q(i))
                        Q(j).S=Q(j).S+1;
                        dom(j,i)=true;

                    end

                end
            end

            S=[Q.S];
            for i=1:nQ
                Q(i).R=sum(S(dom(:,i)));
            end

            Z=[Q.Cost]';
            SIGMA=pdist2(Z,Z,'seuclidean');
            SIGMA=sort(SIGMA);
            for i=1:nQ
                Q(i).sigma=SIGMA(:,i);
                Q(i).sigmaK=Q(i).sigma(K);
                Q(i).D=1/(Q(i).sigmaK+2);
                Q(i).F=Q(i).R+Q(i).D;
            end

            nND=sum([Q.R]==0);
            if nND<=nArchive
                F=[Q.F];
                [F, SO]=sort(F);
                Q=Q(SO);
                archive=Q(1:min(nArchive,nQ));

            else
                SIGMA=SIGMA(:,[Q.R]==0);
                archive=Q([Q.R]==0);

                k=2;
                while numel(archive)>nArchive
                    while min(SIGMA(k,:))==max(SIGMA(k,:)) && k<size(SIGMA,1)
                        k=k+1;
                    end

                    [~, j]=min(SIGMA(k,:));

                    archive(j)=[];
                    SIGMA(:,j)=[];
                end

            end

            PF_Ess=archive([archive.R]==0); % Approximate Pareto Front
            
            figure(1);
            PFC=[PF_Ess.Cost];
            PlotCosts2(PFC);
            pause(0.0001); 

            disp(['Problem= ' num2str(Problem) ' : Run= ' num2str(run) ' : Iteraion ' num2str(it) ': Number of Rep Members = ' num2str(numel(PF_Ess))]);
            IGDs(it,run)=IGD([PF_Ess.Cost]',PF);
            HVs(it,run)=HV([PF_Ess.Cost]',PF);
            
            if it>=MaxIt
                break;
            elseif it<=round(MaxIt/2)  % PSO

                for i=1:nPop
                    W  = unifrnd(0.05,0.5,nVar,1);
                    r1 = rand(nVar,1);
                    r2 = rand(nVar,1);
                    C1 = unifrnd(0.5,2,nVar,1);
                    C2 = unifrnd(0.5,2,nVar,1);   
                    ind=TournamentSelection(archive,[archive.F]);
                    GBest=archive(ind);
                    pop(i).Velocity = W.*pop(i).Velocity ...
                        +C1.*r1.*(pop(i).PBest-pop(i).Position) ...
                        +C2.*r2.*(GBest.Position-pop(i).Position);

                    pop(i).Position = pop(i).Position + pop(i).Velocity;

                    pop(i).Position = max(pop(i).Position, VarMin);
                    pop(i).Position = min(pop(i).Position, VarMax);

                    pop(i).Cost = CostFunction((pop(i).Position)');

                    if Dominates(pop(i).Cost,pop(i).PCost)
                        pop(i).PBest=pop(i).Position;
                        pop(i).PCost=pop(i).Cost;
                    elseif ~Dominates(pop(i).PCost, pop(i).Cost)
                        SC1=sum(pop(i).Cost);                
                        SC2=sum(pop(i).PCost);
                        if SC1<SC2
                            pop(i).PBest=pop(i).Position;
                            pop(i).PCost=pop(i).Cost;
                        end
                    end
                end        

            else   % GA
                % Crossover
                popc=repmat(empty_individual,nCrossover/2,2);
                for c=1:nCrossover/2

                    p1=BinaryTournamentSelection(archive,[archive.F]);
                    p2=BinaryTournamentSelection(archive,[archive.F]);

                    [popc(c,1).Position, popc(c,2).Position]=Crossover(p1.Position,p2.Position,crossover_params, nVar);

                    popc(c,1).Cost=CostFunction((popc(c,1).Position)');
                    popc(c,2).Cost=CostFunction((popc(c,2).Position)');

                end
                popc=popc(:);

                % Mutation
                popm=repmat(empty_individual,nMutation,1);
                for m=1:nMutation

                    p=BinaryTournamentSelection(archive,[archive.F]);

                    popm(m).Position=Mutate(p.Position,mutation_params);

                    popm(m).Cost=CostFunction((popm(m).Position)');

                end

                % Create New Population
                pop=[popc
                     popm];
            end
                        
        end

        %% Results
        Rep_Whole{run}=PF_Ess;
        save(['D://EAPS3_' problemName '_10000NFE.mat'],'HVs','IGDs', 'PF_Ess', 'Rep_Whole');
    end
end
