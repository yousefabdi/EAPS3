function PopObj = ZDT4(PopDec)
    PopObj(:,1) = PopDec(:,1);
    g = 1 + 10*(size(PopDec,2)-1) + sum(PopDec(:,2:end).^2-10*cos(4*pi*PopDec(:,2:end)),2);
    h = 1 - (PopObj(:,1)./g).^0.5;
    PopObj(:,2) = g.*h;
    PopObj=PopObj';
end
