function p=TournamentSelection(pop,f)

    n=numel(pop);
    
    I=randsample(n,4);
    
    Fs=f(I);
    [~,minF]=min(Fs);
    
    p=(I(minF));
end